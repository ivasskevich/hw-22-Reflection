﻿using System.Collections;
using System.Reflection;

namespace Programs
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Assembly ac_group = Assembly.LoadFrom("./Academy-Group.dll");
                Assembly stud = Assembly.LoadFrom("./Student.dll");

                Type groupType = ac_group.GetType("Academy_Groups.Academy_Group");
                object group = Activator.CreateInstance(groupType);

                bool exit = false;

                while (!exit)
                {
                    Console.WriteLine("\nMenu:");
                    Console.WriteLine("1. Add Student");
                    Console.WriteLine("2. Remove Student");
                    Console.WriteLine("3. Edit Student");
                    Console.WriteLine("4. Print Group");
                    Console.WriteLine("5. Sort by Average");
                    Console.WriteLine("6. Sort by Surname");
                    Console.WriteLine("7. Save to File");
                    Console.WriteLine("8. Load from File");
                    Console.WriteLine("9. Search Student by Surname");
                    Console.WriteLine("10. Iterate Students (using foreach)");
                    Console.WriteLine("11. Showing how work Clone group");
                    Console.WriteLine("12. Exit");
                    Console.Write("Choose an option: ");
                    int choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            Console.Write("Name: ");
                            string name = Console.ReadLine();
                            Console.Write("Surname: ");
                            string surname = Console.ReadLine();
                            Console.Write("Age: ");
                            int age = int.Parse(Console.ReadLine());
                            Console.Write("Phone: ");
                            string phone = Console.ReadLine();
                            Console.Write("Average: ");
                            double average = double.Parse(Console.ReadLine());
                            Console.Write("Group Number: ");
                            string groupNumber = Console.ReadLine();

                            Type studentType = stud.GetType("Students.Student");
                            ConstructorInfo studentConstructor = studentType.GetConstructor([typeof(string), typeof(string), typeof(int), typeof(string), typeof(double), typeof(string)]);
                            object student = studentConstructor.Invoke([name, surname, age, phone, average, groupNumber]);

                            MethodInfo addMethod = groupType.GetMethod("Add");
                            addMethod.Invoke(group, [student]);
                            break;

                        case 2:
                            Console.Write("Enter surname of the student to remove: ");
                            string removeSurname = Console.ReadLine();
                            MethodInfo removeMethod = groupType.GetMethod("Remove");
                            removeMethod.Invoke(group, [removeSurname]);
                            break;

                        case 3:
                            Console.Write("Enter surname of the student to edit: ");
                            string editSurname = Console.ReadLine();
                            Console.Write("New Name: ");
                            string newName = Console.ReadLine();
                            Console.Write("New Age: ");
                            int newAge = int.Parse(Console.ReadLine());
                            Console.Write("New Phone: ");
                            string newPhone = Console.ReadLine();
                            Console.Write("New Average: ");
                            double newAverage = double.Parse(Console.ReadLine());
                            Console.Write("New Group Number: ");
                            string newGroupNumber = Console.ReadLine();

                            Type newStudentType = stud.GetType("Students.Student");
                            ConstructorInfo newStudentConstructor = newStudentType.GetConstructor([typeof(string), typeof(string), typeof(int), typeof(string), typeof(double), typeof(string)]);
                            object newStudent = newStudentConstructor.Invoke([newName, editSurname, newAge, newPhone, newAverage, newGroupNumber]);

                            MethodInfo editMethod = groupType.GetMethod("Edit");
                            editMethod.Invoke(group, [editSurname, newStudent]);
                            break;

                        case 4:
                            MethodInfo printMethod = groupType.GetMethod("Print");
                            printMethod.Invoke(group, null);
                            break;

                        case 5:
                            MethodInfo sortByAverageMethod = groupType.GetMethod("SortByAverage");
                            sortByAverageMethod.Invoke(group, null);
                            Console.WriteLine("Sorted by average.");
                            break;

                        case 6:
                            MethodInfo sortBySurnameMethod = groupType.GetMethod("SortBySurname");
                            sortBySurnameMethod.Invoke(group, null);
                            Console.WriteLine("Sorted by surname.");
                            break;

                        case 7:
                            Console.Write("Enter file path to save: ");
                            string savePath = Console.ReadLine();
                            MethodInfo saveMethod = groupType.GetMethod("Save");
                            saveMethod.Invoke(group, [savePath]);
                            break;

                        case 8:
                            Console.Write("Enter file path to load: ");
                            string loadPath = Console.ReadLine();
                            MethodInfo loadMethod = groupType.GetMethod("Load");
                            loadMethod.Invoke(group, [loadPath]);
                            break;

                        case 9:
                            Console.Write("Enter surname to search: ");
                            string searchSurname = Console.ReadLine();
                            MethodInfo searchMethod = groupType.GetMethod("Search");
                            object foundStudent = searchMethod.Invoke(group, [searchSurname]);

                            if (foundStudent != null)
                            {
                                MethodInfo printStudentMethod = foundStudent.GetType().GetMethod("Print");
                                printStudentMethod.Invoke(foundStudent, null);
                            }
                            break;

                        case 10:
                            Console.WriteLine("Iterating over students:");
                            MethodInfo getEnumeratorMethod = groupType.GetMethod("GetEnumerator");
                            var enumerator = (IEnumerator)getEnumeratorMethod.Invoke(group, null);

                            while (enumerator.MoveNext())
                            {
                                var currentStudent = enumerator.Current;
                                MethodInfo studentPrintMethod = currentStudent.GetType().GetMethod("Print");
                                studentPrintMethod.Invoke(currentStudent, null);
                            }
                            break;

                        case 11:
                            Console.WriteLine("Showing how Clone works:");

                            MethodInfo addCloneStudentMethod = groupType.GetMethod("Add");
                            ConstructorInfo sampleStudentConstructor = stud.GetType("Students.Student").GetConstructor(
                            [
                                typeof(string), typeof(string), typeof(int), typeof(string), typeof(double), typeof(string)
                            ]);

                            object student1 = sampleStudentConstructor.Invoke(["Alice", "Johnson", 20, "123456789", 4.5, "CS101"]);
                            object student2 = sampleStudentConstructor.Invoke(["Bob", "Smith", 22, "987654321", 3.7, "CS102"]);

                            addCloneStudentMethod.Invoke(group, [student1]);
                            addCloneStudentMethod.Invoke(group, [student2]);

                            MethodInfo cloneMethod = groupType.GetMethod("Clone");
                            object clonedGroup = cloneMethod.Invoke(group, null);

                            Console.WriteLine("Original Group:");
                            MethodInfo originalPrintMethod = groupType.GetMethod("Print");
                            originalPrintMethod.Invoke(group, null);

                            Console.WriteLine("\nCloned Group:");
                            originalPrintMethod.Invoke(clonedGroup, null);

                            Console.WriteLine("\nAdding a new student to the original group...");
                            object student3 = sampleStudentConstructor.Invoke(["Charlie", "Brown", 21, "555555555", 4.0, "CS103"]);
                            addCloneStudentMethod.Invoke(group, [student3]);

                            Console.WriteLine("\nUpdated Original Group:");
                            originalPrintMethod.Invoke(group, null);

                            Console.WriteLine("\nCloned Group After Modification:");
                            originalPrintMethod.Invoke(clonedGroup, null);
                            break;

                        case 12:
                            exit = true;
                            break;

                        default:
                            Console.WriteLine("Invalid option.");
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.ToString()}");
            }
        }
    }

}