﻿using System.Collections;
using Students;

namespace Academy_Groups
{
    class Academy_Group : ICloneable, IEnumerable<Student>
    {
        private ArrayList students;

        public Academy_Group()
        {
            students = new ArrayList();
        }

        public void Add(Student student)
        {
            students.Add(student);
        }

        public void Remove(string surname)
        {
            for (int i = 0; i < students.Count; i++)
            {
                if (((Student)students[i]).Surname == surname)
                {
                    students.RemoveAt(i);
                    return;
                }
            }
            Console.WriteLine("Student not found.");
        }

        public void Edit(string surname, Student updatedStudent)
        {
            for (int i = 0; i < students.Count; i++)
            {
                if (((Student)students[i]).Surname == surname)
                {
                    students[i] = updatedStudent;
                    return;
                }
            }
            Console.WriteLine("Student not found.");
        }

        public void Print()
        {
            foreach (Student student in students)
            {
                student.Print();
            }
        }

        public void SortByAverage()
        {
            for (int i = 0; i < students.Count - 1; i++)
            {
                for (int j = 0; j < students.Count - 1 - i; j++)
                {
                    if (((Student)students[j]).Average > ((Student)students[j + 1]).Average)
                    {
                        var temp = students[j];
                        students[j] = students[j + 1];
                        students[j + 1] = temp;
                    }
                }
            }
        }

        public void SortBySurname()
        {
            for (int i = 0; i < students.Count - 1; i++)
            {
                for (int j = 0; j < students.Count - 1 - i; j++)
                {
                    if (string.Compare(((Student)students[j]).Surname, ((Student)students[j + 1]).Surname) > 0)
                    {
                        var temp = students[j];
                        students[j] = students[j + 1];
                        students[j + 1] = temp;
                    }
                }
            }
        }

        public void Save(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (Student student in students)
                {
                    writer.WriteLine($"{student.Name};{student.Surname};{student.Age};{student.Phone};{student.Average};{student.Number_Of_Group}");
                }
            }
        }

        public void Load(string filePath)
        {
            students.Clear();
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    var parts = line.Split(';');
                    var student = new Student(parts[0], parts[1], int.Parse(parts[2]), parts[3], double.Parse(parts[4]), parts[5]);
                    students.Add(student);
                }
            }
        }

        public Student Search(string surname)
        {
            foreach (Student student in students)
            {
                if (student.Surname.Equals(surname, StringComparison.OrdinalIgnoreCase))
                {
                    return student;
                }
            }
            Console.WriteLine("Student not found.");
            return null;
        }

        public object Clone()
        {
            Academy_Group clonedGroup = new Academy_Group();
            foreach (Student student in students)
            {
                clonedGroup.Add(new Student(student.Name, student.Surname, student.Age, student.Phone, student.Average, student.Number_Of_Group));
            }
            return clonedGroup;
        }

        public IEnumerator<Student> GetEnumerator()
        {
            foreach (Student student in students)
            {
                yield return student;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }

}
