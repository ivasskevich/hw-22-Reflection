﻿using Persons;
using System;

namespace Students
{
    public class Student : Person, IComparable<Student>
    {
        public double Average { get; set; }
        public string Number_Of_Group { get; set; }

        public Student() { }

        public Student(string name, string surname, int age, string phone, double average, string numberOfGroup)
            : base(name, surname, age, phone)
        {
            Average = average;
            Number_Of_Group = numberOfGroup;
        }

        public override void Print()
        {
            base.Print();
            Console.WriteLine($", Average: {Average}, Group: {Number_Of_Group}");
        }

        public int CompareTo(Student other)
        {
            if (other == null) return 1;

            return Average.CompareTo(other.Average);
        }
    }

}
